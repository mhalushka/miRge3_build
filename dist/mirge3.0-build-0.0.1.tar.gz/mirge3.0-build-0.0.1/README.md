# miRge3_build
Enables building small-RNA libraries for organism of choice to use in miRge3.0 pipeline.

### Update: package migration to python3.8
Storage for library building tools. miRge_bowtie_build.py works with miRge 3.0. It is designed to allow a user to build specialty libraries for any species of interest to use with miRge 3.0.
